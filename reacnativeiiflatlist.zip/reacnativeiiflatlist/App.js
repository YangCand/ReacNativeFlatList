import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, Image } from 'react-native';

const App = () => {
  const [data, setData] = useState([
    {
      id: 1,
      image: { uri: 'https://asset-a.grid.id//crop/0x0:0x0/700x465/photo/2018/05/25/3236581364.jpg' }, 
      title: 'Echodible Packagin',
      price: 'Rp15.534',
      sold: '1,3RB terjual',
      discount: '-5%',
      customWriting: 'FREE box kemasan',
      rating: 4.9,
    },
    {
      id: 2,
      image: { uri: 'https://s.alicdn.com/@sc04/kf/U536ed20415ea4875b75aae846849c4abW.jpg_720x720q50.jpg' }, 
      title: 'Sedotan Ramah Lingkungan',
      price: 'Rp17.388',
      sold: '22,5RB terjual',
      discount: '',
      customWriting: '',
      lanyard: '',
      rating: 5,
    },
    {
      id: 3,
      image: { uri: 'https://down-id.img.susercontent.com/file/51b02326486876f9ac2289416c6c8d94' }, 
      title: 'Kemasan Box Souvenir',
      price: 'Rp5.850',
      sold: '713 terjual',
      discount: '',
      customWriting: '',
      lanyard: '',
      rating: 4.5,
    },
    {
      id: 4,
      image: { uri: 'https://media.licdn.com/dms/image/D5603AQHblZPc4KnRIg/profile-displayphoto-shrink_800_800/0/1706107696844?e=2147483647&v=beta&t=6jMOhIbeGUuXHJCb_s8CJSOe6U7ZhCeHN2-Wb8UOD2E' }, 
      title: 'Cetak Foto 50 lembar 5x6',
      price: 'Rp 15.000',
      sold: '1,5RB terjual',
      discount: '-10%',
      customWriting: 'Free ongkir',
      lanyard: '',
      rating: 4.7,
    },
    {
      id: 5,
      image: { uri: 'https://down-id.img.susercontent.com/file/53cfe69de2a985d47d51aed4b96dda3a' },
      title: 'Parfume Yves Saint Laurent',
      price: 'Rp 600.000',
      sold: '500 terjual',
      discount: '-15%',
      customWriting: '',
      lanyard: '',
      rating: 4.6,
    },
    {
      id: 6,
      image: { uri: 'https://pbs.twimg.com/media/EW1gO81UcAAXWLC?format=jpg&name=large' }, 
      title: 'Sewa Pacar',
      price: 'Rp 150.000',
      sold: '800 terjual',
      discount: '-10%',
      customWriting: 'Free Sleep Call',
      lanyard: '',
      rating: 100000,
    },
        {
      id: 7,
      image: { uri: 'https://www.apple.com/v/ipad-pro/al/images/overview/hero/hero_combo__fcqcc3hbzjyy_large.jpg' },
      title: 'iPad Pro',
      price: 'Rp 5.000.000',
      sold: '20 terjual',
      discount: '-45%',
      customWriting: '',
      lanyard: '',
      rating: 4.6,
    },
    {
      id: 8,
      image: { uri: 'https://images.tokopedia.net/img/cache/700/hDjmkQ/2023/2/10/3e6b9a04-a6de-49ee-a722-5e3b11bb4521.jpg' }, 
      title: 'Light Stick Blackpink Official',
      price: 'Rp 150.000',
      sold: '800 terjual',
      discount: '-10%',
      customWriting: 'Free Ongkir',
      lanyard: '',
      rating: 4.8,
    },
  ]);

  const renderItem = ({ item }) => (
    <View style={styles.productItem}>
      <Image source={item.image} style={styles.productImage} />
      <View style={styles.productInfo}>
        <Text style={styles.productTitle}>{item.title}</Text>
        <Text style={styles.productPrice}>{item.price}</Text>
        <Text style={styles.productSold}>{item.sold}</Text>
        {item.discount && (
          <Text style={styles.productDiscount}>{item.discount}</Text>
        )}
        {item.customWriting && (
          <Text style={styles.productCustomWriting}>{item.customWriting}</Text>
        )}
        {item.lanyard && (
          <Text style={styles.productLanyard}>{item.lanyard}</Text>
        )}
        <View style={styles.productRating}>
          <Text>{item.rating}/5 </Text>
        </View>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={data}
        renderItem={renderItem}
        keyExtractor={(item) => item.id.toString()}
        numColumns={2}
        columnWrapperStyle={styles.row}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
    backgroundColor: '#f5f5f5',
  },
  row: {
    flex: 1,
    justifyContent: 'space-between',
  },
  productItem: {
    backgroundColor: '#fff',
    flex: 1,
    margin: 5,
    padding: 10,
    borderRadius: 10,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 5,
    elevation: 3,
  },
  productImage: {
    width: '100%',
    height: 150,
    resizeMode: 'contain',
    marginBottom: 10,
  },
  productInfo: {
    flexDirection: 'column',
  },
  productTitle: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  productPrice: {
    fontSize: 14,
    fontWeight: 'bold',
    marginTop: 5,
  },
  productSold: {
    fontSize: 12,
    marginTop: 5,
  },
  productDiscount: {
    fontSize: 12,
    color: 'red',
    marginTop: 5,
  },
  productCustomWriting: {
    fontSize: 12,
    color: 'green',
    marginTop: 5,
  },
  productLanyard: {
    fontSize: 12,
    color: 'blue',
    marginTop: 5,
  },
  productRating: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 5,
  },
});

export default App;
